https://www.youtube.com/watch?v=CBODsOAMQkw
https://www.youtube.com/watch?v=EFv-38heLmg
https://www.youtube.com/watch?v=W_yowneZAaI
https://www.youtube.com/watch?v=jgpUVdnzljs
https://www.youtube.com/watch?v=epPlVPMyk3c